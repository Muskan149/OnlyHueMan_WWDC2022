
import Foundation
import UIKit
import SwiftUI


extension UILabel {
    func setTyping(text: String, characterDelay: TimeInterval = 4) {
        self.text = ""
        
        let writingTask = DispatchWorkItem { [weak self] in
            text.forEach { char in
                DispatchQueue.main.async {
                    self?.text?.append(char)
                }
                Thread.sleep(forTimeInterval: characterDelay/100)
            }
        }
        
        let queue: DispatchQueue = .init(label: "typespeed", qos: .userInteractive)
        queue.asyncAfter(deadline: .now() + 0.05, execute: writingTask)
    }
    
}





struct AnimTest : View {
    var body : some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10).foregroundColor(.white)
            UIKitLabelView(text: "This is a very long test sentence.This is a very long test sentence.This is a very long test sentence.")
                .padding()
        }
    }
}





@IBDesignable
class PaddingLabel: UILabel {
    var textEdgeInsets = UIEdgeInsets.zero {
        didSet { invalidateIntrinsicContentSize() }
    }
    
    open override func textRect(forBounds bounds: CGRect, limitedToNumberOfLines numberOfLines: Int) -> CGRect {
        let insetRect = bounds.inset(by: textEdgeInsets)
        let textRect = super.textRect(forBounds: insetRect, limitedToNumberOfLines: numberOfLines)
        let invertedInsets = UIEdgeInsets(top: -textEdgeInsets.top, left: -textEdgeInsets.left, bottom: -textEdgeInsets.bottom, right: -textEdgeInsets.right)
        return textRect.inset(by: invertedInsets)
    }
    
    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: textEdgeInsets))
    }
    
    @IBInspectable
    var paddingLeft: CGFloat {
        set { textEdgeInsets.left = newValue }
        get { return textEdgeInsets.left }
    }
    
    @IBInspectable
    var paddingRight: CGFloat {
        set { textEdgeInsets.right = newValue }
        get { return textEdgeInsets.right }
    }
    
    @IBInspectable
    var paddingTop: CGFloat {
        set { textEdgeInsets.top = newValue }
        get { return textEdgeInsets.top }
    }
    
    @IBInspectable
    var paddingBottom: CGFloat {
        set { textEdgeInsets.bottom = newValue }
        get { return textEdgeInsets.bottom }
    }
}



struct UIKitLabelView : UIViewRepresentable {
    
    var text : String
    var color : Color =  Color.white
    var centeredText = false
    var isARule = false
    
    var fontFactor : CGFloat {
        centeredText ? MagicNumbers.textSize1 * 1.5 : MagicNumbers.textSize2
    }
    
    
    func makeUIView(context: Context) -> UILabel {
        
        let label = PaddingLabel()
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 0
        label.textColor = isARule ? .white : .black
        label.backgroundColor = isARule ? ColorPalette.color3 : UIColor(color)
        label.textAlignment = centeredText ? .center : .natural
        label.font = .systemFont(ofSize: fontFactor * min(UIScreen.main.bounds.width, UIScreen.main.bounds.height),
                                 weight: centeredText ? .bold : .regular)
        label.preferredMaxLayoutWidth = MagicNumbers.titleWidth * UIScreen.main.bounds.width * 0.8
        label.layer.cornerRadius = 50
        label.setTyping(text: text)
        if centeredText {
        label.font = UIFont(name: "Samarkan", size: fontFactor * min(UIScreen.main.bounds.width, UIScreen.main.bounds.height))
        }
        
        
        
        // PADDING
            label.paddingLeft = 75
            label.paddingRight = 75
        

        return label
        
    }
    
    func updateUIView(_ uiView: UILabel, context: Context) {
        
    }
    
    
    typealias UIViewType = UILabel
    
    
}

struct StoryLabel : UIViewRepresentable {
    
    @Binding var text : String
    var centeredText = false
    var isARule = false
    
    var fontFactor : CGFloat {
        MagicNumbers.textSize2
    }
    
    
    func makeUIView(context: Context) -> UILabel {
        
        let label = PaddingLabel()
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 0
        label.textColor = .white
        label.backgroundColor = ColorPalette.color3
        label.textAlignment = .natural
        label.font = .systemFont(ofSize: fontFactor * min(UIScreen.main.bounds.width, UIScreen.main.bounds.height),
                                 weight: .regular)
        label.preferredMaxLayoutWidth = MagicNumbers.titleWidth * UIScreen.main.bounds.width * 0.8
        label.layer.cornerRadius = 50
        label.setTyping(text: text)
        
        
        
        // PADDING
            label.paddingLeft = 75
            label.paddingRight = 75
            
        
        

        return label
        
    }
    
    func updateUIView(_ uiView: UILabel, context: Context) {
        
    }
    
    
    typealias UIViewType = UILabel
    
    
}

