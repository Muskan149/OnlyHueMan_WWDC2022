import SwiftUI

struct BrownRuleCard: View {
    var text : String
    var buttonClicked : () -> Void
    @State var textAppear = false
    
    
    var body: some View {
        ZStack (alignment: .top) {
            Rectangle().foregroundColor(Color(ColorPalette.color3))
                .onAppear {
                    textAppear = true
                }
            VStack {
                Spacer().frame(height: UIScreen.main.bounds.height * 0.125 * 0.5)
                Image(systemName: "book.fill").font(.system(size: 100))
                Spacer().frame(height: UIScreen.main.bounds.height * 0.125 * 0.3)
                Text("RULES").font(.system(size: 50)).bold().padding(.bottom)
                Spacer().frame(height: UIScreen.main.bounds.height * 0.125 * 0.3)
                Text(.init(text)).font(.system(size: 30)).padding(.all)
                    .opacity(textAppear ? 1 : 0).animation(.easeIn(duration: 1.0), value: textAppear)
                    .frame(width: UIScreen.width * 4/5)
                Spacer()
                HStack {
                    Spacer()
                    Button(action: buttonClicked
                           , label: {
                        Image(systemName: "arrowshape.turn.up.right.circle.fill")
                            .symbolVariant(.fill)
                            .foregroundStyle(.black, .brown)
                            .font(.largeTitle)
                            .padding()
                    })
                    
                }
            }.foregroundColor(.white)
            
            HStack {
                BackButton(action: {opDat.currView = .beTheChange})
                Spacer()
            }
            
            
    
            
        }.ignoresSafeArea()
        
    }
}

struct BrownRuleCard_Previews: PreviewProvider {
    static var previews: some View {
        RulesForFaceTimeCall()
.previewInterfaceOrientation(.landscapeLeft)
    }
}




struct RulesForBiasShiftGame : View {
    var body: some View {
        BrownRuleCard(text: "In the following game, you will get a series of thoughts inside thought bubbles. \n\n**Single Tap** on a thought bubble to applaud the thought and **Double Tap** on a thought that is biased and trash it.",
                      buttonClicked: {opDat.currView = .thoughtsGame}
        )
    }
}

struct RulesForFaceTimeCall : View {
    var body: some View {
        BrownRuleCard(text: "Bias regarding our skin colour and beauty mostly has its roots from our family and their flawed expectations. \n\nContinue ahead and join a certified therapist in a call where you and your family can engage in a fruitful and important discussion regarding colourism.",
                      buttonClicked: {opDat.currView = .faceTimeAlert}
        )
    }
}



struct RulesForCompanyGame : View {
    var body: some View {
        BrownRuleCard(text: "Retail industry and popular media has a significant effect on the way we perceive skin shade and beauty. In the upcoming game, you will get to see the case studies of a few hypothetical companies. \n\n**Swipe Right** on the card if you think that the company is promoting color positivity and **Swipe Left** if you think it is encouraging colourism.",
                      buttonClicked: {opDat.currView = .companyGame}
        )
    }
}

































//struct BrownBannerInCorrectAnswer : View {
//    var body: some View {
//        ZStack {
//            Rectangle().fill(Color(uiColor: ColorPalette.color3)).ignoresSafeArea()
//                .overlay {
//                }
//
//
//        }
//    }
//}
//BrownBannerDontKnow().opacity(noWorriesAlert ? 1 : 0).animation(Animation.linear)
//            Button {
//                print("booyah")
//            } label: {
//                Image(systemName: "arrowshape.turn.up.right.circle.fill")
//                    .symbolVariant(.fill)
//                    .foregroundStyle(.black, .brown)
//                    .padding()
//                    .font(.largeTitle)
//                    .opacity(noWorriesAlert ? 1 : 0)
//            }

