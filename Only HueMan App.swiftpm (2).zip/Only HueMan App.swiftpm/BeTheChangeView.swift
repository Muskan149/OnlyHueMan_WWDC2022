

import SwiftUI

struct BeTheChange: View {
    
    @State var scaledCognition = false
    @State var scaledSwipe = false
    @State var scaledTherapy = false
    
    @State var scaled = false

    
    var body: some View {
        VStack {
            GeometryReader { geometry in
                VStack {
                Title("FIRST STEP TO CHANGE", proxy: geometry)
                        .overlay(alignment: .topLeading) {
                            BackButton {
                                opDat.currView = .seventhLine
                            }.padding(.horizontal)
                        }
                        .onAppear {
                            withAnimation {
                                scaled = true
                            }
                        }
                    Spacer(minLength: 30)
                    HStack {
                        ZStack {
                            RoundedRectangle(cornerRadius: 15.0)
                                .fill(Color(uiColor: ColorPalette.color1))
                                .dropShadow()
                                .aspectRatio(4/3, contentMode: .fit)
                                .padding()
                            VStack {
                                Text("👨‍👩‍👧‍👦")
                                    .padding()
                                    .font(.system(size:min(geometry.size.width/4, geometry.size.height/4) * 0.4 ))
                                Text("Family Therapy")
                                    .foregroundColor(.white)
                                    .font(.title2)
                                    .bold()
                                    .padding(.bottom)
                            }
                        }
                            .onTapGesture {
                                opDat.currView = .faceTimeRules
                            }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15.0)
                                .fill(Color(uiColor: ColorPalette.color2))
                                .dropShadow()
                                .aspectRatio(4/3, contentMode: .fit)
                                .padding()
                            VStack {
                                Text("📲")
                                    .padding()
                                    .font(.system(size:min(geometry.size.width/4, geometry.size.height/4) * 0.4 ))
                                Text("Swipe for Change")
                                    .foregroundColor(.white)
                                    .font(.title2)
                                    .bold()
                                    .padding(.bottom)
                            }
                        }

                        .onTapGesture {
                            opDat.currView = .companyRules
                        }
                    }.frame(width: geometry.size.width * 0.9 , height: geometry.size.height/2 * 0.6)
                        .opacity(scaled ? 1 : 0)
                    ZStack {
                        RoundedRectangle(cornerRadius: 15.0)
                            .fill(Color(uiColor: ColorPalette.color3))
                            .dropShadow()
                            .aspectRatio(4/3, contentMode: .fit)
                            .padding()

                        VStack {
                            Text("💭")
                                .padding()
                                .font(.system(size:min(geometry.size.width/4, geometry.size.height/4) * 0.4 ))
                            Text("Combat Your Bias")
                                .foregroundColor(.white)
                                .font(.title2)
                                .bold()
                                .padding(.bottom)

                        }
                    }.onTapGesture {
                            withAnimation {
                                opDat.currView = .cognitionRules
                            }
                        }
                    .opacity(scaled ? 1 : 0)
                    .frame(width: geometry.size.width * 0.5 * 0.9 , height: geometry.size.height/2 * 0.6)
                    Spacer(minLength: 30)
                    HStack {
                        Spacer()
                        BackButton(forward: true, action: {opDat.currView = .thankYou})
                    }
                }
            }
        }
    }
}

struct BeTheChange_Previews: PreviewProvider {
    static var previews: some View {
        BeTheChange()
            .preferredColorScheme(.light)
            .previewInterfaceOrientation(.landscapeRight)
    }
}

























struct Title : View {
    
    var name: String
    var proxy : GeometryProxy
    
    init(_ name: String, proxy: GeometryProxy) {
        self.name = name
        self.proxy = proxy
    }
    
    var body: some View {
        VStack {
            ResizedImage("Background1",
                         dims: proxy)
                .overlay(
                    VStack {
                        Text(name)
                            .foregroundColor(.white)
                            .font(
                                .system(
                                    size: MagicNumbers.textSize2 * min(proxy.size.width, proxy.size.height)
                                )
                            )
                    }
                )
        }.ignoresSafeArea()
    }
    
    
}
