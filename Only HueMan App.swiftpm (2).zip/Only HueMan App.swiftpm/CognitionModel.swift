

import Foundation

class CognitionShiftModel {
    
    var thoughts : [Thought]

    
    init() {
        self.thoughts  = [

            
            Thought(thought: "cloud1", shouldBeTrashed: false, id: 0, isScaled: true, isFirst: true),
            Thought(thought: "cloud2", shouldBeTrashed: true, id: 1, isScaled: false),
            Thought(thought: "cloud3", shouldBeTrashed: false, id: 2, isScaled: false),
            Thought(thought: "cloud4", shouldBeTrashed: true, id: 3, isScaled: false),

            

            ].reversed()
        }
    
    
    struct Thought : Identifiable {
        var thought : String
        var shouldBeTrashed : Bool
        var id: Int
        var isScaled = false
        var isFirst = false

        func validate(shouldBeTrashed response: Bool) -> Bool {
            if response == self.shouldBeTrashed {
                return true
            } else {
                return false
            }
        }
    }
    
    

    
    
    
    

    
}



