
import SwiftUI
import AVKit

struct CognitionShiftView: View {
    
    
    var model = CognitionShiftModel()
    @State var nThoughts = 1
    @State var nSmashed = 0
    @State var celebrationOpacity = 0.0
    @State var crossOpacity = 0.0
    @State var audioPlayer : AVAudioPlayer?

    @State var gameOver = false
    @State var correct = 0
    @State var incorrect = 0
    
    
    
    
    
    var bottomRibbon : some View {
        ZStack {
            Rectangle().foregroundColor(Color(uiColor: ColorPalette.color3))
                .overlay {
                    HStack {
                        Spacer()
                        HStack {
                            Image(systemName: "trash.fill")
                                .font(.largeTitle)
                            VStack(alignment : .leading) {
                                Text("Trash the thought : Double click")
                                    .fontWeight(.bold)
                            }
                        }
                        Spacer()
                        HStack {
                            Image(systemName: "hands.clap.fill")
                                .font(.largeTitle)
                            VStack(alignment : .leading) {
                                Text("Applaud the thought : Single click")
                                    .fontWeight(.bold)
                            }
                        }
                        Spacer()
                    }.foregroundColor(.white)
                }
            
        }.frame(height: UIScreen.main.bounds.height/9, alignment: .center)
    }
    
    
    
    
    var body: some View {
        VStack (spacing: 0) {
            ZStack (alignment : .topLeading) {
                Color.init(uiColor: ColorPalette.color1)
                BackgroundImage()
                    .onAppear {
                        ScoreCard.correct = 0
                        ScoreCard.incorrect = 0
                    }
                BackButton {
                        opDat.currView = .cognitionRules
                }.padding()
                ForEach(model.thoughts) {thought in
                    Image(thought.thought)
                        .resizable()
                        .frame(width: UIScreen.main.bounds.width * 0.5, height: UIScreen.main.bounds.width * 0.5)
                        .foregroundColor(.white)
//                        .overlay (alignment: .center){
//                            ZStack {
//                                Text(thought.thought)
//                                    .foregroundColor(.black)
//                                    .frame(width: UIScreen.main.bounds.width * 0.2, height: UIScreen.main.bounds.width * 0.2 * 16/29 )
//                                    .font(.system(size: UIScreen.main.bounds.width * 0.33 * MagicNumbers.textSize2))
//                            }.scaleEffect(0.9)
//                        }
                        .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY - UIScreen.main.bounds.midY/9)
                        .scaleEffect(thought.isScaled ? 1 : 0.3)
                        .animation(Animation.easeInOut(duration: 1.2))
                        //.transition(AnyTransition.scale(scale: 2))
                            .onTapGesture(count: 2) {
                                if model.thoughts.count == 1{
                                    withAnimation {
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                            opDat.currView = .scoreCognition
                                        }
                                    }
                                    
                                }
                                if thought.validate(shouldBeTrashed: true) {
                                    celebrationOpacity = 1
                                    ScoreCard.correct += 1
                                    print(celebrationOpacity)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        celebrationOpacity = 0
                                    }
                                } else {
                                    ScoreCard.incorrect += 1
                                    crossOpacity = 1
                                    print(crossOpacity)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        crossOpacity = 0
                                    }
                                }
                                if model.thoughts.count != 0 {
                                    model.thoughts.removeLast()
                                    if model.thoughts.count > 0 {
                                        model.thoughts[model.thoughts.count - 1].isScaled = true
                                    }
                                }
                            }
                            .onTapGesture(count: 1) {
                                if model.thoughts.count == 1{
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        opDat.currView = .scoreCognition
                                    }
                                }
                                if thought.validate(shouldBeTrashed: false) {
                                    ScoreCard.correct += 1
                                    celebrationOpacity = 1
                                    print(celebrationOpacity)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        celebrationOpacity = 0
                                    }
                                    
                                } else {
                                    ScoreCard.incorrect += 1
                                    crossOpacity = 1
                                    print(crossOpacity)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        crossOpacity = 0
                                    }
                                }
                                if model.thoughts.count != 0 {
                                    model.thoughts.removeLast()
                                    if model.thoughts.count > 0 {
                                        model.thoughts[model.thoughts.count - 1].isScaled = true
                                    }
                                }
                            }
                        
                            
                        
                }
                
                Correct()
                    .opacity(celebrationOpacity)
                    .animation(Animation.spring())
                    .position(x: UIScreen.main.bounds.minX + 200, y: UIScreen.main.bounds.minY + 200)

                
                Incorrect()
                    .opacity(crossOpacity)
                    .animation(Animation.spring())
                    .position(x: UIScreen.main.bounds.minX + 200, y: UIScreen.main.bounds.minY + 200)

                
                
            }.frame(height: UIScreen.height * 7.9/9)
            bottomRibbon
            Spacer()

        }
        
    }

}



struct Correct : View {
    var body: some View {
        Circle()
            .fill(.green)
            .frame(width: 200, height: 200, alignment: .center)
            .overlay(
                VStack {
                    Text("✅")
                    Text("Correct").foregroundColor(.white)
                }
                    .scaleEffect(2)
            )

        
    }
}

struct Incorrect : View {
    var body : some View {
        Circle()
            .fill(.red)
            .frame(width: 200, height: 200, alignment: .center)
            .overlay(
                VStack {
                    Text("❌")
                    Text("Wrong").foregroundColor(.white)
                }
                    .scaleEffect(3)
            )
    }
}


struct BackgroundImage : View {
    var body : some View {
        Image("brain1").resizable().scaledToFill()
    }

}

struct GameOver : View {
    var body : some View {
        Image("muk").resizable().scaledToFill().ignoresSafeArea()
        
    }

}

struct ScoreCard : View {
    static var correct   = 0
    static var incorrect = 0
    
    var bottomRibbon : some View {
        ZStack {
            Rectangle().foregroundColor(Color(uiColor: ColorPalette.color3))
                .overlay {
                    HStack {
                        Spacer()
                        HStack {
                            Image(systemName: "trash.fill")
                                .font(.largeTitle)
                            VStack(alignment : .leading) {
                                Text("Trash the thought : Double click")
                                    .fontWeight(.bold)
                            }
                        }
                        Spacer()
                        HStack {
                            Image(systemName: "hands.clap.fill")
                                .font(.largeTitle)
                            VStack(alignment : .leading) {
                                Text("Applaud the thought : Single click")
                                    .fontWeight(.bold)
                            }
                        }
                        Spacer()
                    }.foregroundColor(.white)
                    
                }
            
        }.frame(height: UIScreen.main.bounds.height/9, alignment: .center)
    }
    
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack(alignment : .topLeading) {
                Color.init(uiColor: ColorPalette.color1)
                BackgroundImage()
                BackButton(action: {opDat.currView = .beTheChange} ).padding()
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(Color(uiColor: ColorPalette.color3))
                    .frame(width: UIScreen.width/3, height: UIScreen.width/3 * 0.4, alignment: .center)
                    .overlay {
                        VStack {
                            Text("Your Score").font(.largeTitle).bold().foregroundColor(.white)
                            Spacer().frame(height:  UIScreen.width/3 * 0.03)
                            Text("Correct : \(ScoreCard.correct)").foregroundColor(.white).font(.title)
                            Text("Incorrect: \(ScoreCard.incorrect)").foregroundColor(.white).font(.title)
                        }
                    }
                    .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)

            }.frame(height: UIScreen.height * 7.9/9)
            bottomRibbon
            Spacer()

        }
        
    }
}



struct BackButton : View {
    var forward = false
    var action : () -> Void = {opDat.currView = .beTheChange}
    var body: some View {
        Button(action: action) {
            Image(systemName: forward ? "arrowshape.turn.up.right.circle.fill" :  "arrowshape.turn.up.left.circle.fill")
                    .symbolVariant(.fill)
                    .foregroundStyle(.black, .brown)
                    .padding()
                    .font(.largeTitle)
                    .offset(x: 0, y: forward ? 0 : 10)
        }
    }
}


struct CognitionShift_Previews: PreviewProvider {
    static var previews: some View {
        CognitionShiftView()
            .previewInterfaceOrientation(.landscapeRight)
        CognitionShiftView()
            .previewInterfaceOrientation(.portrait)
        
    }
}


