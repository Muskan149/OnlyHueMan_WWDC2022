
import SwiftUI

struct CompanyCardView: View {
    
    let proxy: GeometryProxy
    let threshold = 0.25
    @GestureState var translation: CGSize = .zero
    @GestureState var degrees: Double = 0
    @GestureState var isDragging: Bool = false
    @GestureState var correctDrag : Bool = true
    
    var index : Int
    let company : Company
    var removeCard : ((Int) -> Void)?
    
    
    var body: some View {
        let dragGesture = DragGesture()
            .updating($correctDrag){ (new, old, _) in
                old = Float(new.translation.width) * company.celebrateNumber >= 0.0
            }
            .updating($translation) { (new, old, _) in
                old = new.translation
            }
            .updating($isDragging) { (new, old, _) in
                old = new.translation.width != 0
            }
            .updating($degrees) { (new, old, _) in
                old = new.translation.width > 0 ? 2 : -2
            }
            .onEnded { (new) in
                
                let dragPercentage = new.translation.width / (proxy.size.width)
                print(dragPercentage)
                
                
                if abs(dragPercentage) > threshold {
                    removeCard?(index)
                    if Float(dragPercentage) * company.celebrateNumber >= 0.0 {
                        AyNayScoreCard.correct += 1
                    } else {
                        AyNayScoreCard.incorrect += 1
                    }
                }
            }
        
        ZStack {
            RoundedRectangle(cornerRadius: 30)
                .foregroundColor(Color(uiColor: ColorPalette.color3))
                .overlay {
                    VStack {
                        Spacer().frame(height: UIScreen.height * 3/5 * 1/15)
                        Text(company.emoji)
                            .font(.system(size:UIScreen.height * 3/9 * 0.3))
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .padding()
                        
                        Text(company.name)
                            .font(.system(size: UIScreen.height * 3/9 * 0.13))
                            .foregroundColor(.white)
                            .fontWeight(.bold)
                            .padding()
                            .multilineTextAlignment(.center)

                        Text(company.description)
                            .multilineTextAlignment(.center)
                            .font(.system(size: UIScreen.height * 3/9 * 0.08))
                            .foregroundColor(.white)
                            .padding()
                        Spacer()
                    }
                }
                .frame(width: UIScreen.height * 3/9, height : UIScreen.height * 3/5)
            
            Circle()
                .fill(Color(uiColor: ColorPalette.color2))
                .frame(width: proxy.size.width * 1/4 , height: proxy.size.height * 1/4)
                .overlay {
                    
                    VStack {
                        Text("👎").font(.system(size: proxy.size.width * 1/11))
                        Text("**NAY**").font(.largeTitle)
                    }.foregroundColor(.white)
                }
                .position(x: UIScreen.main.bounds.midX -  UIScreen.main.bounds.midX * 1/3,
                          y: proxy.frame(in: .local).midY)
                .opacity(degrees < 0 ? 1 : 0)
                .scaleEffect(isDragging &&  degrees < 0 ? 1.2 : 1)
                .animation(.default)
            
            Circle()
                .fill(Color(uiColor: ColorPalette.color2))
                .frame(width: proxy.size.width * 1/4 , height: proxy.size.height * 1/4)
                .overlay {
                    VStack {
                        Text("👍").font(.system(size: proxy.size.width * 1/11))
                        Text("**YAY**").font(.largeTitle)
                    }.foregroundColor(.white)
                }
                .position(x: UIScreen.main.bounds.midX + 1/3 * UIScreen.main.bounds.midX,
                          y: proxy.frame(in: .local).midY)
                .opacity(degrees > 0 ? 1 : 0)
                .scaleEffect(isDragging &&  degrees > 0 ? 1.2 : 1)
                .animation(.default)
            
        }.cornerRadius(10)
            .offset(x: translation.width, y: 0)
            .rotationEffect(.degrees(degrees))
            .scaleEffect(company.isBehind ? 0.35 : 1)
            .gesture(dragGesture)
            .animation(.interactiveSpring())
    }
}


struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        GeometryReader { proxy in
            AyNayScoreCard()
        }
        .previewInterfaceOrientation(.landscapeLeft)
    }
}




struct Company {
    var emoji : String
    var name : String
    var description : String
    var isBehind = true
    var celebrate = false
    var celebrateNumber : Float {
        celebrate ? 1 : -1
    }
    
}


// && Double(company.celebrateNumber) * degrees > 0.0







struct AyNayScoreCard : View {
    
    static var correct = 0
    static var incorrect  = 1
        
    var body: some View {
        GeometryReader { geometry in
        VStack(spacing: 0) {
            ZStack(alignment: .topLeading) {
                Title("SWIPE ⬅️ FOR NAY , ➡️ FOR YAY", proxy: geometry)
//                Image("Background1")
//                    .resizable()
//                    .scaledToFill()
//                    .frame(width: UIScreen.width
//                           ,height: UIScreen.height * MagicNumbers.titleTopStrip1Height)
//                    .clipped()
//                    .overlay(
//                        Text("Swipe ⬅️ for NAY , ➡️ for YAY")
//                            .foregroundColor(.white)
//                            .font(
//                                .system(
//                                    size: MagicNumbers.textSize2 * min(UIScreen.main.bounds.width, UIScreen.main.bounds.height)
//                                )
//                            )
//                    )
                BackButton(action: {opDat.currView = .beTheChange})
            }.frame(width: UIScreen.width, height: UIScreen.height / 5)
                .ignoresSafeArea()
            RoundedRectangle(cornerRadius: 25)
                .foregroundColor(Color(uiColor: ColorPalette.color3))
                .frame(width: UIScreen.width/3, height: UIScreen.width/3 * 0.4, alignment: .center)
                .overlay {
                    VStack {
                        Text("Your Score").font(.largeTitle).bold().foregroundColor(.white)
                        Spacer().frame(height:  UIScreen.width/3 * 0.03)
                        Text("Correct : \(AyNayScoreCard.correct)").foregroundColor(.white).font(.title)
                        Text("Incorrect: \(AyNayScoreCard.incorrect)").foregroundColor(.white).font(.title)
                    }
                }
                .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY * 5/8)
        }
        }.ignoresSafeArea()
}
}
