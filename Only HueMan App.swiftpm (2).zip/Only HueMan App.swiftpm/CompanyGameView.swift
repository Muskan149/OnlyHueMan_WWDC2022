import SwiftUI
 
struct AyOrNay: View {
    
    @State var companies = PackOfCompaniesView.companies
    @State var cardsAppear = false
    
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                
                
                ZStack(alignment: .topLeading) {
                    Title("SWIPE ⬅️ FOR NAY , ➡️ FOR YAY", proxy: geometry)
                        .onAppear {
                                                AyNayScoreCard.correct = 0
                                                AyNayScoreCard.incorrect = 0
                                                withAnimation(.easeIn(duration: 0.2)) {
                                                cardsAppear = true
                                                }
                                            }
                    BackButton(action: {opDat.currView = .companyRules})
                }.frame(width: UIScreen.width, height: UIScreen.height / 5)
                ZStack {
                    ForEach(Array(companies.enumerated()), id : \.offset) { index, company in
                        CompanyCardView(proxy: geometry,
                                        index: index,
                                        company: company) { (index) in
                            companies.remove(at: index)
                            if companies.count == 0 {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                    withAnimation {
                                        opDat.currView = .scoreAyNay
                                    }
                                }
                            }
                            if index > 0 {
                                companies[index - 1].isBehind = false
                            }
                            
                        }
                        
                    }
                }.padding()
                    .opacity(cardsAppear ? 1 : 0)
            }
            
        }.ignoresSafeArea()
    }
}
 
 
 
 
struct PackOfCompaniesView {
    
    static let companies = [
    Company(emoji: "🥻", name: "SanaWear", description: "This Indian ethic-wear brand has a history of casting both light and dark-skinned models for its product launch photoshoots.", celebrate: true),
    Company(emoji: "🧴", name: "Glow Pvt. Ltd.", description: "In its lightening cream ad, this brand claimed that a lighter skin tone will help its customers get better job opportunities."),
    Company(emoji: "💄", name: "Shades of Beauty", description: "This Indian cosmetic brand offers cosmetic products designed for all skin tones, contrary to many global brands.", celebrate: true),
    Company(emoji: "💍", name: "Wedzo.com", description: "This matrimonial website has a filter based on 'skin complexion'.", isBehind: false)
    ]
    
}
 
struct FactorsAffectingPsyche_Previews: PreviewProvider {
    static var previews: some View {
        
        AyOrNay()
            .previewInterfaceOrientation(.landscapeRight)
            .previewDevice("iPad Pro (9.7-inch)")
            //.previewDevice("iPad Pro (12.9-inch) (5th generation)")
        
        AyOrNay()
            .previewInterfaceOrientation(.landscapeRight)
            //.previewDevice("iPad Pro (9.7-inch)")
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")
}
}


