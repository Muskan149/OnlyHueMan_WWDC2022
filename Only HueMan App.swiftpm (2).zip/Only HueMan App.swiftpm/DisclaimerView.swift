
import Foundation
import SwiftUI

struct DisclaimerView: View {
    var text : String
    var buttonClicked = {opDat.currView = .welcome}
    @State var textAppear = false
    
    
    var body: some View {
        ZStack (alignment: .top) {
            Rectangle().foregroundColor(Color(ColorPalette.color3))
                .onAppear {
                    textAppear = true
                }
            VStack {
                Spacer().frame(height: UIScreen.main.bounds.height * 0.125 * 0.7)
                Image(systemName: "ipad.landscape").font(.system(size: 100))
                Spacer().frame(height: UIScreen.main.bounds.height * 0.125 * 0.4)
                Text("BEFORE WE BEGIN").font(.system(size: 50)).bold().padding(.bottom)
                Spacer().frame(height: UIScreen.main.bounds.height * 0.125 * 0.4)
                Text(.init(text)).font(.system(size: 30)).padding(.all)
                    .opacity(textAppear ? 1 : 0).animation(.easeIn(duration: 1.0), value: textAppear)
                    .multilineTextAlignment(.center)
                    .frame(width: UIScreen.width * 4/5)
                Spacer()
                HStack {
                    Spacer()
                    Button(action: buttonClicked
                           , label: {
                        Image(systemName: "arrowshape.turn.up.right.circle.fill")
                            .symbolVariant(.fill)
                            .foregroundStyle(.black, .brown)
                            .font(.largeTitle)
                            .padding()
                    })
                    
                }
            }.foregroundColor(.white)
                        
    
            
        }.ignoresSafeArea()
        
    }
}
