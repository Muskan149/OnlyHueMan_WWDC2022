
import AVKit
import AVFoundation
import SwiftUI

struct FaceTimeAlert: View {

    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Rectangle().fill(Color(uiColor: ColorPalette.color1)).ignoresSafeArea()
                FaceTimePromptCardView(geometry: geometry)
            }
        }
    }
}

struct FaceTimeAlert_Previews: PreviewProvider {
    static var previews: some View {
        FaceTimeAlert()
            .previewInterfaceOrientation(.portraitUpsideDown)
    }
}


struct FaceTimePromptCardView : View {
    @State var audioPlayer  : AVAudioPlayer!
    let url = URL(fileURLWithPath: Bundle.main.path(forResource: "ftAudio", ofType: "mp3")!)

    
    var geometry : GeometryProxy
    @State var hovered = false
    @State var hovered2 = false

    
    var body: some View {
        HStack {
            Spacer()
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(Color(uiColor: ColorPalette.faceTimeGrey))
                    .aspectRatio(4/1, contentMode: .fit).padding().frame(width: geometry.size.width * 0.7)
                    .dropShadow()
                    .overlay(
                        HStack(alignment: .center) {
                            Image("therapist")
                                .resizable()
                                .frame(width: geometry.size.width * 0.7 * 0.4 * 0.4, height: geometry.size.width * 0.7 * 0.4 * 0.4)
                                .cornerRadius(80)
                            VStack (alignment: .leading){
                                Text("Harvinder Kaur")
                                    .foregroundColor(.white)
                                    .font(.title)
                                    .bold()
                                Text("Internationally Certified")
                                    .foregroundColor(.white)
                                    .font(.title2)
                                Text("Pyschologist")
                                    .foregroundColor(.white)
                                    .font(.title2)
                            }
                            .aspectRatio(4/1, contentMode: .fit).frame(width: geometry.size.width * 0.7 * 0.4, alignment: .leading)
                            VStack {
                                Button(action: {
                                    self.audioPlayer.stop()
                                    opDat.currView = .faceTimeVideo
                                    print("accepted")
                                }) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(uiColor: ColorPalette.faceTimeAccept))
                                            .aspectRatio(4/1, contentMode: .fit).padding().frame(width: geometry.size.width * 0.7 * 0.3)
                                        Text("Accept")
                                            .foregroundColor(.white)
                                            .font(.title2)
                                        
                                    }.scaleEffect(hovered ? 1.05 : 1)
                                        .animation(.interactiveSpring(), value: hovered)
                                        .onHover { isHovered in
                                            self.hovered = isHovered
                                        }
                                }
                                
                                Button(action: {
                                    opDat.currView = .beTheChange
                                }) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color(uiColor: ColorPalette.faceTimeDecline))
                                            .aspectRatio(4/1, contentMode: .fit).padding().frame(width: geometry.size.width * 0.7 * 0.3)
                                        Text("Decline")
                                            .foregroundColor(.white)
                                            .font(.title2)
                                    }.scaleEffect(hovered2 ? 1.05 : 1)
                                        .animation(.interactiveSpring(), value: hovered2)
                                        .onHover { isHovered in
                                            self.hovered2 = isHovered
                                        }

                                }
                                
                            }.aspectRatio(contentMode: .fit)
                        }
                    
                    )
                
            }
            Spacer()
         
            
        }.onAppear {
            self.audioPlayer = try! AVAudioPlayer(contentsOf: url)
            self.audioPlayer.play()
        }
        
        
        
        
    }
}


