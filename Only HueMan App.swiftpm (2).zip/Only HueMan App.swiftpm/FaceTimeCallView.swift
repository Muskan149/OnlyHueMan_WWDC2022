import Foundation
import AVKit
import AVFoundation
import AVFAudio
import SwiftUI



struct FaceView : View {
    
    
    @State var mute = false
    @State var isOn = true
    @State var player = AVPlayer()
    var playerViewController = AVPlayerViewController()
    
    var body: some View {
        
        VStack(spacing : 0) {
            
            PlayerViewFinal()

            
                ZStack {
                    Rectangle()
                        .foregroundColor(.black)
                        .frame(height: UIScreen.main.bounds.height/8)
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            withAnimation(.linear) {
                                mute.toggle()
                                
                            }
                        }) {
                            ZStack {
                                if !mute {
                                    Image(systemName: "mic.slash.circle.fill")
                                        .foregroundColor(.blue)
                                        .font(.system(size: MagicNumbers.faceTimeControlsHeight))
                                } else {
                                    Image(systemName: "mic.circle.fill")
                                        .foregroundColor(.green)
                                        .font(.system(size: MagicNumbers.faceTimeControlsHeight))
                                        
                                }
                            }
                            
                        }
                        
                        Spacer()

                        Button(action: {
                            player.pause()
                            opDat.currView = .beTheChange
                            
                        }) {
                            Image(systemName: "phone.circle.fill")
                                .foregroundColor(Color(uiColor: ColorPalette.faceTimeDecline))
                                .font(.system(size: MagicNumbers.faceTimeControlsHeight))
                        }
                        Spacer()
                    }.padding(.bottom)
                }

            
            
            
        }.ignoresSafeArea()
                

    }
}



extension MagicNumbers {
    static let faceTimeControlsHeight = UIScreen.main.bounds.height/8 * 0.5
}
struct VideoController_Previews: PreviewProvider {
    static var previews: some View {
        FaceView()
.previewInterfaceOrientation(.landscapeLeft)
    }
}
