

import SwiftUI

struct FactorsAffectingPsyche: View {
    let color1 = UIColor(hexaString: "#b3793b")
    let color2 = UIColor(hexaString: "#ca9a5e")
    let color3 = UIColor(hexaString: "#7e4d20")

    let hWidth = UIScreen.main.bounds.width * 0.9
    
    @State var scaled = false
    
    
    var body: some View {
        GeometryReader { geometry in
            VStack (alignment: HorizontalAlignment.trailing) {
                Title("FACTORS AFFECTING THE INDIAN PSYCHE", proxy: geometry)
                    .overlay(alignment: .topLeading) {
                        BackButton {
                            opDat.currView = .fourthLine
                        }.padding(.horizontal)
                    }.onAppear {
                        withAnimation(.easeIn) {scaled = true}
                        
                    }
                Spacer().frame(height: UIScreen.height * 0.1)
                HStack(alignment: .center) {
                    Spacer()
                    CardView(emoji: "👑",
                             textIn: "British colonialism created a system of institutionalised segregation that favoured the lighter-skinned Indians in terms of treatment by colonists and army recruiters.",
                             color: color3,
                             width: hWidth * 1/3 * 0.8,
                             height: hWidth * 1/3 * 0.7 * 5/3,
                             title : "Colonialism"
                    )
                    CardView(emoji: "🎬",
                             textIn: "Indian film insutry is notorious for casting light-skinned protagnists, while portraying darker-skinned actors as their arch-nemesis.",
                             color: color1,
                             width: hWidth * 1/3 * 0.8,
                             height: hWidth * 1/3 * 0.7 * 5/3,
                             title : "Film Industry"
                    )
                    CardView(emoji: "💄",
                             textIn: "Cosmetic and wellness industry capitalises off of colourism by promoting skin 'lightening' and 'whitening' creams and bleaches.",
                             color: color2,
                             width: hWidth * 1/3 * 0.8,
                             height: hWidth * 1/3 * 0.7 * 5/3,
                             title : "Cosmetic Industry"
                    )
                    Spacer()
                    
                }
                .opacity(scaled ? 1 : 0)
                .padding(.horizontal)
                Spacer()
                HStack {
                    Spacer()
                    BackButton(forward: true, action: {opDat.currView = .fifthLine})
                    //.padding()
                }
            }
        }.ignoresSafeArea()
        
        
    }
}




struct ResizedImage: View {
    var image : String
    var dims : GeometryProxy
    
    init(_ image: String, dims: GeometryProxy) {
        self.image = image
        self.dims = dims
        
    }
    
    var body: some View {
        
        Image(image)
        /*.resizable()
         .scaledToFit()
         .frame(width: dims.size.width
         ,height: dims.size.height * MagicNumbers.titleTopStrip1Height)*/
            .resizable()
            .scaledToFill()
            .frame(width: dims.size.width
                   ,height: dims.size.height * MagicNumbers.titleTopStrip1Height)
            .clipped()
    }
}

extension MagicNumbers {
    static let titleTopStrip1Height : CGFloat = 0.2
    
}


struct CardView : View {
    var emoji : String
    var textIn : String
    var color : UIColor
    var width : CGFloat
    var height : CGFloat
    var title : String
    
    @State var textVisible = false
    @State var flashcardRotation = 0.0
    @State var contentRotation = 0.0
    
    var body : some View {
        
        // Spacer()
        ZStack{
            RoundedRectangle(cornerRadius: 25.0)
                .foregroundColor(Color(uiColor: color))
            
                .frame(width: width, height: height)
                .padding()
                .shadow(color: .black, radius: 7)
                .overlay {
                    if !textVisible {
                        Text(emoji).font(.system(size: min(width, height) * 0.45))
                    }
                    else {
                        VStack (spacing: 0.0) {
                            Text(title)
                                .font(.system(size: min(width, height) * 0.17))
                            //.font(.system(size: 35))
                                .frame(width: width * 0.9)
                                .padding(.horizontal)
                                .multilineTextAlignment(.center)
                            Text(textIn)
                                .font(.system(size: min(width, height) * 0.08))
                            //.font(.system(size: 20))
                                .frame(width: width * 0.9)
                                .padding(.horizontal)
                                .padding(.top)
                                .multilineTextAlignment(.center)
                            
                        }.foregroundColor(.white)
                        
                    }
                }.rotation3DEffect(.degrees(contentRotation), axis: (x: 0, y: 1, z: 0))
            
            
        }
        .onTapGesture {
            flipFlashcard()
        }
        .rotation3DEffect(.degrees(flashcardRotation), axis: (x: 0, y: 1, z: 0))
        // Spacer()
    }
    
    func flipFlashcard() {
        
        let animationTime = 0.5
        withAnimation(Animation.linear(duration: animationTime)) {
            flashcardRotation += 180
        }
        
        withAnimation(Animation.linear(duration: 0.001).delay(animationTime / 2)) {
            contentRotation += 180
            textVisible.toggle()
        }
        
    }
    
    
}



extension UIColor {
    convenience init(hexaString: String, alpha: CGFloat = 1) {
        let chars = Array(hexaString.dropFirst())
        self.init(red:   .init(strtoul(String(chars[0...1]),nil,16))/255,
                  green: .init(strtoul(String(chars[2...3]),nil,16))/255,
                  blue:  .init(strtoul(String(chars[4...5]),nil,16))/255,
                  alpha: alpha)}
}


struct DiversityFactors_Previews: PreviewProvider {
    static var previews: some View {
        FactorsAffectingPsyche()
            .previewDevice("iPad Pro (9.7-inch)")
            .previewInterfaceOrientation(.landscapeLeft)
    }
}


//             .previewDevice("iPad Pro (12.9-inch) (5th generation")

