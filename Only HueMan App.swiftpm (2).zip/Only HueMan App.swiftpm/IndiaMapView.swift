

import SwiftUI
import Foundation





class ActiveUser : ObservableObject {
    @Published var activeUser : Int? = nil
}

public var actifUser = 8

class ActiveClass : ObservableObject {
    @Published var activeUser = 8 {
        willSet {
            opa = false
        }
        didSet {
            withAnimation(.linear(duration: 1)){
                opa = true
            }
        }
    }
    @Published var opa = true
}


struct IndiaStories: View {
    
    
    
    @StateObject var c = ActiveClass()
//    var activeUserClass : ActiveUser {
//        StoryImage.activeUserTracker
//    }
    
    var body: some View {
    VStack (spacing: 0.0) {
        GeometryReader { geometry in
            ZStack {
                Rectangle().fill(Color(uiColor: ColorPalette.color1)).ignoresSafeArea()
                    .overlay(alignment: .topLeading) {
                        BackButton {
                            opDat.currView = .fifthLine
                        }.padding(.horizontal)
                    }
//                    .onAppear {
//                        self.activeUserClass = StoryImage.activeUserTracker
//                    }
                
                Image("map0")
                    .resizable()
                    .scaledToFit()
                    .padding()
                
                StoryImage(person: Persons.persons[0], c)
                    .position(x: geometry.frame(in: .global).midX + 30, y: geometry.frame(in: .global).midY + 10)
//                    .onTapGesture {
//                        activeUseer = 0
//                        print("hello")
//                    }
                
                    //.offset(x: 30, y : 10)
                    
                StoryImage(person: Persons.persons[1], c)
                    .position(x: geometry.frame(in: .global).midX - 180, y: geometry.frame(in: .global).midY + 0)
//                    .onTapGesture {
//                        activeUseer = 1
//                        print("hello")
//
//                    }
                    //.offset(x: -180, y : 0)
                
                

                StoryImage(person: Persons.persons[2], c)
                    .frame(
                        width:  UIScreen.height * 1/13  ,
                        height: UIScreen.height * 1/13)
                    .position(x: geometry.frame(in: .global).midX - 120, y: geometry.frame(in: .global).midY - 200)
//                    .onTapGesture {
//                        activeUseer = 2
//                        print("hello")
//
//                    }
                    //.offset(x: -120, y : -200)

                StoryImage(person: Persons.persons[3], c)
                    .frame(width: UIScreen.height * 1/13, height: UIScreen.height * 1/13)
                    //.position(x: 100, y: 200)
                    .position(x: geometry.frame(in: .global).midX - 100, y: geometry.frame(in: .global).midY + 230)
//                    .onTapGesture {
//                        activeUseer = 3
//                        print("hello")
//
//                    }
                    //.offset(x: -100, y : 230)
                //Image("srk").resizable().cornerRadius(100).padding().background(.red)
            }
        }
        StoryBoard()
            .environmentObject(c)
            //.environmentObject(StoryImage.activeUserTracker)
        }.ignoresSafeArea()
        
        
    }
}


struct StoryImage : View {
    //@EnvironmentObject var active : ActiveClass
    let activeClassRef : ActiveClass
    var person : Person
    
    init (person : Person, _ activeClassRef : ActiveClass) {
        self.person = person
        self.activeClassRef = activeClassRef
    }
    
    @State var scaled = false

    var body : some View {
        Image(person.imgName).resizable().cornerRadius(100)
            .frame(
                width:  UIScreen.height * 1/13  ,
                height: UIScreen.height * 1/13)
            .padding()
            .background(.clear)
            .scaleEffect(scaled ? 1.3 : 1)
            .onTapGesture {
                scaled = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    scaled = false
                }
                activeClassRef.activeUser = person.id
            }
    }
}

// 7, 8


struct StoryBoard : View {
    
    @State var opa = true
    @EnvironmentObject var active : ActiveClass
    //@Binding var activeUser : Int
    var body : some View {
        HStack (spacing : 0.0){
            if active.activeUser != 8 {
                Image(Persons.persons[active.activeUser].imgName).resizable().cornerRadius(100)
                    .frame(
                        width:  UIScreen.height * 1/7  ,
                        height: UIScreen.height * 1/7)
                    .padding()
                    .background(Color(uiColor: ColorPalette.color1))
            } else {
                Image(systemName: "person.crop.circle").resizable().cornerRadius(100)
                    .frame(
                        width:  UIScreen.height * 1/7  ,
                        height: UIScreen.height * 1/7)
                    .padding()
                    .foregroundColor(.black)
                    .background(Color(uiColor: ColorPalette.color1))
            }
            ZStack (alignment : .topLeading) {
                RoundedRectangle(cornerRadius: 15.0)
                    .fill()
                    .frame(height: UIScreen.main.bounds.height * 1/8)
                    .overlay {
                        ScrollView {
                        HStack (alignment : .top) {
                            //StoryLabel(text: active.activeUser != 8 ? Persons.persons[active.activeUser].story : "Click on a person and their story will appear here.")
                            Text(active.activeUser != 8 ? Persons.persons[active.activeUser].story : "Click on a person and their story will appear here.\nScroll down if the entire text is not visible.")
                                .opacity(active.opa ? 1 : 0)
                                .foregroundColor(.white)
                                .font(.system(.title2))
                                .padding()
                            Spacer()
                        }
                    }
                    }
            }
            BackButton(forward: true, action: {opDat.currView = .seventhLine})
        }.foregroundColor(Color(uiColor: ColorPalette.color3))
            .padding(.bottom)
            .background(Color(uiColor: ColorPalette.color1))
            //.frame(height: UIScreen.main.bounds.height * 1/8)

    }
}








//struct StoryBanner : View {
//    var story : String = "The person's stories will be entered here."
//
//    var body: some View {
//        ZStack {
//            RoundedRectangle(cornerRadius: 15.0)
//                .fill()
//                .frame(height: UIScreen.main.bounds.height * 1/8)
//                .overlay {
//                    HStack {
//                        Text(story)
//                            .foregroundColor(.white)
//                            .font(.system(.title2))
//                            .padding()
//                        Spacer()
//                    }
//                }
//                .padding()
//
//        }
//    }
//}

struct IndiaStories_Previews: PreviewProvider {
    static var previews: some View {
        
        IndiaStories()
            .previewInterfaceOrientation(.landscapeRight)
            .previewDevice("iPad Pro (9.7-inch)")
            //.previewDevice("iPad Pro (12.9-inch) (5th generation)")
        
        IndiaStories()
            .previewInterfaceOrientation(.landscapeRight)
            //.previewDevice("iPad Pro (9.7-inch)")
            .previewDevice("iPad Pro (12.9-inch) (5th generation)")

    }
}


struct Person {
    var id : Int
    var imgName : String
    var story : String
    
}


struct Persons {
    static var persons = [
        Person(id: 0, imgName: "girl1", story: "As a lawyer, I have observed that inside a courtroom, I had to try harder to get the same orders that a lighter-skinned lawyer would get easily."),
        Person(id: 1, imgName: "girl2", story: "I have been asked blatantly how I am going to get married with my dark skin.  Some aunties ask me diplomatically—\"Why don’t you do something for your tan?\" I have to repeat it so many times—\"This is not tan, this is my colour.\""),
        Person(id: 2, imgName: "albinism1", story: "I have inherited albinism from my parents, a genetic condition which leads to white pigmentation on the skin and hair. Growing up, I was isolated from other students and was excluded from any social activity because people thought that my condition was contagious, or a product of black magic."),
        Person(id: 3, imgName: "girl3", story: "During my teenage years, my mother would take me to the dermatologist to make me fair-skinned, it affected my self-esteem growing up. I was told to apply turmeric on my face to get a lighter skin. It’s OK when society doesn't accept you, however, it's really hurtful when your own family expects you to change.")
        ]
    
}



