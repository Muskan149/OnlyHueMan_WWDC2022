
import SwiftUI


struct MatchTheDifferenceRules : View {
    
    // User Generated
    var status : String
    @State var scaleText = false
    
    
    // Lego building blocks
    var text : String {
        switch status {
        case "right":
            return "That is correct. Let us reinforce this idea.\n\n In the next exercise, match the definitions given in the first column to either 'Racism' or 'Colourism' by dragging and dropping the blocks to the respective term."
        case "wrong":
            return "That is not correct.\n\nIn the next exercise, match the definitions given in the first column to either 'Racism' or 'Colourism' by dragging and dropping the blocks to the respective term, to understand the difference."
        case "idk":
            return "That's alright. Let us try to understand the difference with an exercise.\n\nIn the next exercise, match the definitions given in the first column to either 'Racism' or 'Colourism' by dragging and dropping the blocks to the respective term."
        case "correct":
            return "Colourism involves discrimination against individuals with a dark skin tone, typically among people of the **same ethnic or racial group**."
        default:
            return "error"
        }
    }
    
    var backButtonAction : () -> Void {
        switch status {
        case "right", "wrong", "idk":
            return {opDat.currView = .thirdLine}
        case "correct":
            return {opDat.currView = .matchTheDifference}
        default:
            return {print("error")}
        }
        
    }
    
    var button : some View  {
        Button {
            if status == "correct" {
                opDat.currView = .fourthLine
            } else {
                opDat.currView = .matchTheDifference
            }
            
        } label: {
            Image(systemName: "arrowshape.turn.up.right.circle.fill")
                .symbolVariant(.fill)
                .foregroundStyle(.black, .brown)
                .padding()
                .font(.largeTitle)
        }
    }
    
    
    var label : some View {
        Rectangle().fill(Color(uiColor: ColorPalette.color3)).ignoresSafeArea()
            .onAppear {
                scaleText = true
            }
            .overlay {
                // UIKitLabelView(text: text, isARule: true)
                
                Text(.init(text))
                    .multilineTextAlignment(.center)
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .opacity(scaleText ? 1 : 0)
                    .animation(.easeIn, value: scaleText)
                    .frame(width: UIScreen.width * 0.8, height: UIScreen.height, alignment: .center)
                    .position(x: UIScreen.main.bounds.midX, y: UIScreen.main.bounds.midY)
            }
    }
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            label
            button
        }.overlay(alignment : .topLeading) {
            BackButton(forward: false, action: backButtonAction)
        }
    }
}


struct MatchTheDifferenceRules_Previews: PreviewProvider {
    static var previews: some View {
        MatchTheDifferenceRules(status: "idk")
            .previewInterfaceOrientation(.landscapeLeft)
    }
}
