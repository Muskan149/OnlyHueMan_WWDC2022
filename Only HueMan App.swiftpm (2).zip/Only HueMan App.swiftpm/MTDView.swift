

import SwiftUI

struct MatchTheDifferences: View {
    
    
    @Namespace var namespace
    
    @State var scaled = false
    
    
    @State var viewState1 =  CGSize.zero
    @State var matchedColorism = false
    @State var turnColorismGreen = false
    
    @State var viewState2 =  CGSize.zero
    @State var matchedRacism = false
    @State var turnRacismGreen = false
    
    @State var racismCoordinates =  (CGFloat(2.0), CGFloat(0.0))
    @State var colorismCoordinates = (CGFloat(0.0), CGFloat(0.0))
    @State var colorismDefinitionCoordinates = (CGFloat(0.0), CGFloat(0.0))
    @State var racismDefinitionCoordinates = (CGFloat(0.0), CGFloat(0.0))
    
    var racismLine : some View {
        Line(entryBlock: CGPoint(x: racismDefinitionCoordinates.0, y: racismDefinitionCoordinates.1),
                         destinationBlock: CGPoint(x: racismCoordinates.0, y: racismCoordinates.1))
    }
    
    var colorismLine : some View {
        Line(entryBlock: CGPoint(x: colorismDefinitionCoordinates.0, y: colorismDefinitionCoordinates.1),
                         destinationBlock: CGPoint(x: colorismCoordinates.0, y: colorismCoordinates.1))
    }
    
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                VStack (spacing: 0) {
                    Title("MATCH THE DEFINITIONS", proxy: geometry)
                            .overlay(alignment: .topLeading) {
                                BackButton {
                                    opDat.currView = .thirdLine
                                }.padding(.horizontal)
                            }
                            .onAppear {
                                withAnimation {
                                    scaled = true
                                }
                            }
                    Spacer().frame(height: geometry.size.height * 0.15)

                    HStack(spacing : 0) {
                        
                        // COLORISM DEFINITION
                        GeometryReader {colorDefiProxy in
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .frame(width: geometry.size.width * 0.3)
                                .aspectRatio(4/2, contentMode: .fit)
                                .foregroundColor(Color(uiColor: ColorPalette.color3))
                                .overlay {
                                    Text("Discrimination occurring **WITHIN** a racial group.")
                                        .font(.title)
                                        .foregroundColor(.white).padding()

                                }
                        }.zIndex(1)
                        .onAppear {
                            colorismDefinitionCoordinates = (colorDefiProxy.frame(in: .global).midX,  colorDefiProxy.frame(in: .global).midY)
                        }
                        .position(x: colorDefiProxy.frame(in: .local).midX,
                                  y: colorDefiProxy.frame(in: .local).midY)
                        .dropShadow()
                            .offset(x: viewState1.width, y: viewState1.height)
                            .gesture(
                                DragGesture(coordinateSpace: .global)
                                    .onChanged {value in
                                        
                                        if !matchedColorism {
                                            viewState1 = value.translation
                                            
                                            
                                            if (value.location.x >= colorismCoordinates.0 - geometry.size.width/8) && abs(value.location.y - colorismCoordinates.1) <= geometry.size.height/8 {
                                                withAnimation {
                                                    turnColorismGreen = true
                                                }
                                            } else {
                                                turnColorismGreen = false
                                            }

                                            
                                        }
                                                                                
                                    }
                                    .onEnded { value in
                                        turnColorismGreen = false
                                        withAnimation {
                                            viewState1 = .zero
                                        }
                                        if (value.location.x >= colorismCoordinates.0 - geometry.size.width/8) && abs(value.location.y - colorismCoordinates.1) <= geometry.size.height/8 {
                                            matchedColorism = true
                                        }
                                        if matchedRacism && matchedColorism {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                                opDat.currView = .answer
                                            }
                                        }
                                    }
                            )
                        }

                        Spacer().frame(width: geometry.size.width * 0.3)
                        GeometryReader { racismProxy in
                            ZStack {
                                    RoundedRectangle(cornerRadius: 25)
                                        .foregroundColor(turnRacismGreen ? .green : .white)
                                        .frame(width: geometry.size.width * 0.3)
                                        .aspectRatio(4/2, contentMode: .fit)
                                    RoundedRectangle(cornerRadius: 25)
                                        .stroke(lineWidth: 3)
                                        .fill(Color(uiColor: ColorPalette.color2))
                                        .frame(width: geometry.size.width * 0.3)
                                        .aspectRatio(4/2, contentMode: .fit)
                                        .overlay {
                                            Text("**RACISM**")
                                                .font(.title)
                                                .foregroundColor(Color(uiColor: ColorPalette.color2))
                                        }
                            }
                            .onAppear {
                                    racismCoordinates = (racismProxy.frame(in: .global).midX,  racismProxy.frame(in: .global).midY)
                                }
                            .position(x: racismProxy.frame(in: .local).midX
                                      , y: racismProxy.frame(in: .local).midY)
                        }
                        
                        

                    }.frame(height: geometry.size.height * 0.2)
                        .scaleEffect(scaled ? 1 : 0)
                    
                    
                    Spacer().frame(height: geometry.size.height * 0.1)

                    // RACISM DEFINITION
                    HStack(spacing : 0) {
                        GeometryReader { raceDefiProxy in
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .frame(width: geometry.size.width * 0.3)
                                .aspectRatio(4/2, contentMode: .fit)
                                .foregroundColor(Color(uiColor: ColorPalette.color3))
                                .overlay {
                                    Text("Discrimination **AMONG** racial groups.")
                                        .font(.title)
                                        .foregroundColor(.white)
                                        .padding()
                                }
                        }
                        .position(x: raceDefiProxy.frame(in: .local).midX, y: raceDefiProxy.frame(in: .local).midY)
                        .onAppear {
                            racismDefinitionCoordinates = (raceDefiProxy.frame(in: .global).midX,  raceDefiProxy.frame(in: .global).midY)
                        }
                        .dropShadow()
                            .offset(x: viewState2.width, y: viewState2.height)
                            .gesture(
                                DragGesture(coordinateSpace: .global)
                                    .onChanged {value in
                                        if !matchedRacism {
                                            viewState2 = value.translation
                                            print(value.location.y)
                                            if (value.location.x >= racismCoordinates.0 - geometry.size.width/8) && abs(value.location.y - racismCoordinates.1) <= geometry.size.height/8 {
                                                turnRacismGreen = true
                                            } else {
                                                turnRacismGreen = false
                                            }
                                        }
                                        
                                    }
                                    .onEnded { value in
                                        if !matchedRacism {
                                            if (value.location.x >= racismCoordinates.0 - geometry.size.width/8) && abs(value.location.y - racismCoordinates.1) <= geometry.size.height/8 {
                                                withAnimation {
                                                    viewState2 = .zero
                                                }
                                                turnRacismGreen = false
                                                matchedRacism = true

                                            } else {
                                                withAnimation {
                                                    viewState2 = .zero
                                                }

                                            }
                                        }
                                        if matchedRacism && matchedColorism {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                                opDat.currView = .answer
                                            }
                                        }
                                    }
                                )
                        }


                        Spacer().frame(width: geometry.size.width * 0.3)
                        
                        GeometryReader { colorTermProxy in
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundColor(turnColorismGreen ? .green : .white)
                                .frame(width: geometry.size.width * 0.3)
                                .aspectRatio(4/2, contentMode: .fit)
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(lineWidth: 3)
                                .fill(Color(uiColor: ColorPalette.color2))
                                .frame(width: geometry.size.width * 0.3)
                                .aspectRatio(4/2, contentMode: .fit)
                                .overlay {
                                    Text("**COLOURISM**")
                                        .font(.title)
                                        .foregroundColor(Color(uiColor: ColorPalette.color2))
                                }
                        }
                        .onAppear {
                                colorismCoordinates = (colorTermProxy.frame(in: .global).midX, colorTermProxy.frame(in: .global).midY)
                            }
                        .position(x: colorTermProxy.frame(in: .local).midX
                                  , y: colorTermProxy.frame(in: .local).midY)
                            

                        
                    }
                    }.frame(height: geometry.size.height * 0.2)
                        .scaleEffect(scaled ? 1 : 0)





                }
            }
        
                
          .background (
                Path {path in
                    //path.move(to: CGPoint(x: colorismCoordinates.0, y: colorismCoordinates.1))
                    if matchedRacism {
                            path.move(to: CGPoint(x: racismDefinitionCoordinates.0, y: racismDefinitionCoordinates.1))
                            path.addLine(to: CGPoint(x: racismCoordinates.0, y: racismCoordinates.1))
                        }
                    if matchedColorism {
                        path.move(to: CGPoint(x: colorismDefinitionCoordinates.0, y: colorismDefinitionCoordinates.1))
                        path.addLine(to: CGPoint(x: colorismCoordinates.0, y: colorismCoordinates.1))
                    }
                    
                    
                }.stroke(Color(uiColor: ColorPalette.color2), lineWidth: 10)
                
          )
        }.ignoresSafeArea()
            .overlay(alignment : .bottomTrailing) {
                BackButton(forward: true, action: {opDat.currView = .answer})
                
            }

        
    }
}



 
struct Line : View {

    var entryBlock : CGPoint
    var destinationBlock : CGPoint

    var body: some View {
        Path { path in
            path.move(to: entryBlock)
            path.addLine(to: destinationBlock)
        }
        .stroke(Color(uiColor: ColorPalette.color2), style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
    }
}



struct MatchTheDifferences_Previews: PreviewProvider {
    static var previews: some View {
        MatchTheDifferences()
            .previewInterfaceOrientation(.landscapeRight)
    }
}
