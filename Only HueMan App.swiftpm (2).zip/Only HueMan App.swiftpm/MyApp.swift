
import SwiftUI

class OpDat : ObservableObject {
    @Published var currView = CurrView.disclaimer
}

var opDat = OpDat()


@main
struct OnlyHueMan_App: App {

    init() {
        let cfURL = Bundle.main.url(forResource: "SAMAN___", withExtension: "TTF")! as CFURL

        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)

    }
    
    var body: some Scene {
            WindowGroup {
                MainView()
                    .environmentObject(opDat)

            }
        
    }
}






struct MainView: View {

    @EnvironmentObject var opData: OpDat

    var body: some View {
        switch(opData.currView) {
            
        case .welcome:
            FirstPage()
                .environmentObject(opData)
        
        case .firstLine:
            SecondPage()
                .environmentObject(opData)
            
        case .secondLine:
            ThirdPage()
                .environmentObject(opData)

        case .thirdLine:
            FourthPage()
                .environmentObject(opData)


        case .idkDifference:
            MatchTheDifferenceRules(status: "idk")

        case .rightDifference:
            MatchTheDifferenceRules(status: "right")

        case .wrongDifference:
            MatchTheDifferenceRules(status: "wrong")

        case .matchTheDifference:
            MatchTheDifferences()

        case .fourthLine:
            FifthPage()
                .environmentObject(opData)

        case .factors:
            FactorsAffectingPsyche()

        case .fifthLine:
            SixthPage()

        case .indiaMap:
            IndiaStories()

        case .sixthLine:
            SeventhPage()

        case .seventhLine:
            EighthPage()

        case .beTheChange:
            BeTheChange()

        case .faceTimeAlert:
            FaceTimeAlert()

        case .faceTimeVideo:
            FaceView()

        case .companyGame:
            AyOrNay()

        case .thoughtsGame:
            CognitionShiftView()

        // rules
        case .companyRules:
            RulesForCompanyGame()

        case .cognitionRules:
            RulesForBiasShiftGame()

        case .faceTimeRules:
            RulesForFaceTimeCall()

        case .scoreCognition:
            ScoreCard()

        case .scoreAyNay:
            AyNayScoreCard()

        case .answer:
            MatchTheDifferenceRules(status: "correct")
            
        case .thankYou:
            ThankYou()
            
        case .disclaimer:
            DisclaimerView(text: "The app is optimised to run on all the versions of iPad Pro.\nKindly, run the app in Landscape Mode for the best experience.")
                
        
        default:
            Text("Hello World")


        }
    }
}

enum CurrView {
    case disclaimer
    case welcome
    case firstLine
    case secondLine
    case thirdLine
    case matchTheDifference
    case fourthLine
    case factors
    case fifthLine
    case indiaMap
    case albinism1
    case sixthLine
    case albinism2
    case seventhLine
    case beTheChange
    case faceTimeAlert
    case faceTimeVideo
    case thoughtsGame
    case companyGame
    case scoreCognition
    case scoreAyNay
    case thankYou

    
    case rightDifference
    case wrongDifference
    case idkDifference
    case answer

    
    case cognitionRules
    case faceTimeRules
    case companyRules
    
    


}

