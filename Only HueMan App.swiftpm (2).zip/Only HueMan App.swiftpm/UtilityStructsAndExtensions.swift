
import SwiftUI
import Foundation
import UIKit

struct DropShadow: ViewModifier {
    func body(content: Content) -> some View {
        content
            .shadow(color: .black, radius: 3)
    }
}

extension View {
    func dropShadow() -> some View {
        modifier(DropShadow())
    }
}

struct ColorPalette {
    static let color1 = UIColor(hexaString: "#ccaf89")
    static let color2 = UIColor(hexaString: "#ca9a5e")
    static let color3 = UIColor(hexaString: "#7e4d20")
    static let color4 = UIColor(hexaString: "#b3793b")
    static let faceTimeGrey = UIColor(hexaString: "#323232")
    static let faceTimeAccept = UIColor(hexaString: "#6bc164")
    static let faceTimeDecline = UIColor(hexaString: "#d34737")
    
}

extension UIScreen {
    static let width = UIScreen.main.bounds.width
    static let height = UIScreen.main.bounds.height
}


class NewFonts : UIFont {
    static public func loadFont() {
        let cfURL = Bundle.main.url(forResource: "Samarkan", withExtension: "ttf")! as CFURL
        if CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil) {
            print("yes")
        }
    }

}

