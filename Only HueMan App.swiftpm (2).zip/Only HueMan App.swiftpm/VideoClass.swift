

import Foundation
import UIKit
import AVFoundation
import SwiftUI



class UIVideoPlayer: UIView {

private var playerLayer = AVPlayerLayer()
private var playerLooper: AVPlayerLooper?

override init(frame: CGRect) {
super.init(frame: frame)
    
    let url = URL(fileURLWithPath: Bundle.main.path(forResource: "therapyVid", ofType: "mp4")!)

// Load video
let playerItem = AVPlayerItem(url: url)

// Setup Player
let player = AVQueuePlayer(playerItem: playerItem)
playerLayer.player = player
playerLayer.videoGravity = .resizeAspectFill
layer.addSublayer(playerLayer)


// Play
player.isMuted = false
player.play()

}

required init?(coder: NSCoder) {
    fatalError()
}

override func layoutSubviews() {
super.layoutSubviews()
playerLayer.frame = bounds
    
}
}





struct PlayerViewFinal: UIViewRepresentable {
    func makeUIView(context: Context) -> UIVideoPlayer {
        return UIVideoPlayer()
    }
    func updateUIView(_ uiView: UIVideoPlayer, context: Context) {
        
    }
}


struct VidFinal_Previews: PreviewProvider {
    static var previews: some View {
        PlayerViewFinal()
    }
}

