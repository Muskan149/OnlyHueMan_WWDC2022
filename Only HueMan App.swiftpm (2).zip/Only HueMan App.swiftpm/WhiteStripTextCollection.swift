

import SwiftUI

struct FirstPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[1]!,onButtonClick: {opDat.currView = .firstLine}, centeredText: true)
        }
    }
}

struct SecondPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[2]!,onButtonClick: {opDat.currView = .secondLine}, onBackButtonClick: {opDat.currView = .welcome})
        }
    }
}

struct ThirdPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[3]!,onButtonClick: {opDat.currView = .thirdLine}, onBackButtonClick: {opDat.currView = .firstLine})
        }
    }
}

struct FourthPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[4]!, onBackButtonClick: {opDat.currView = .secondLine}, showAlert: true)
        }
    }
}


// factors ka back button brings me here
struct FifthPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[5]!,onButtonClick: {opDat.currView = .factors}, onBackButtonClick: {opDat.currView = .answer})
        }
    }
}

struct SixthPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[6]!,onButtonClick: {opDat.currView = .indiaMap}, onBackButtonClick: {opDat.currView = .factors})
        }
    }
}

struct SeventhPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[7]!,onButtonClick: {opDat.currView = .albinism1})
        }
    }
}

struct EighthPage : View {
    var body: some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[8]!,onButtonClick: {opDat.currView = .beTheChange}, onBackButtonClick: {opDat.currView = .indiaMap})
        }
    }
}

struct ThankYou : View {
    var body : some View {
        GeometryReader { geometry in
            WhiteStripTextView(geometry: geometry, text: WhiteStripText.lines[9]!,onButtonClick: {opDat.currView = .beTheChange}, onBackButtonClick: {opDat.currView = .beTheChange}, finalSlide: true)
        }
    }
}




struct WhiteStripTextsCollection_Previews: PreviewProvider {
    static var previews: some View {
        FirstPage()
            .previewInterfaceOrientation(.landscapeRight)
        SecondPage()
            .previewInterfaceOrientation(.landscapeRight)

        ThirdPage()
            .previewInterfaceOrientation(.landscapeRight)

        FourthPage()
            .previewInterfaceOrientation(.landscapeRight)
        
        FifthPage()
            .previewInterfaceOrientation(.landscapeRight)
        
        SixthPage()
            .previewInterfaceOrientation(.landscapeRight)

    }
}

struct WhiteStripText {
    static let lines =  [1: "Only HueMan",
                         2: "India is a conglomeration of diverse traditions and distinct cultures. It also showcases a diversity in the skin tones of its people.",
                         3: "However, over the past few decades,instead of celebrating our differences…",
                         4: "…we have started discriminating against each other based on our skin shade. This practice is called colourism.",
                         5: "Let us try to understand the factors that have shaped the Indian mindset regarding skin colour, beauty and acceptance.",
                         6: "Colourism is a problematic practice. It is widespread in Indian households, schools, and workplaces and has led to hurtful experiences for many.",
                         7: "Only HueMan is my first step towards publicly acknowledging the practice of colourism. Further, I will expand the conversation beyond light and dark skin color & talk about an ignored community.",
                         8: "Let us explore methods to spot and combat colourism in our daily lives through three activities.",
                         9: "Thank you for coming this far! I hope that this project stimulates public discourse regarding colourism and its harmful effects. 🫶"
                         
            ]
}

