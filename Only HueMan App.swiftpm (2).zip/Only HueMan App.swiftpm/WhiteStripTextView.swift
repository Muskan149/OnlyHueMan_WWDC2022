

import SwiftUI

struct WhiteStripTextView: View {
    
    // User gives this
    var geometry : GeometryProxy
    var text : String
    var onButtonClick : (() -> Void) = {print("click")}
    var onBackButtonClick : (() -> Void) = {print("click")}
    
    // For Special purpose
    var centeredText = false
    var showAlert = false
    
    @State var showingAlert = false
    @State var opac = false // sub line opacity
    
    
    // Building blocks
    var button : some View {
        Button(action: showAlert ? {showingAlert = showAlert} : onButtonClick)
        {Image(systemName: "arrowshape.turn.up.right.circle.fill")
                .symbolVariant(.fill)
                .foregroundStyle(.black, .brown)
                .padding()
                .font(.largeTitle)
                .opacity(finalSlide ? 0 : 1)
                .disabled(finalSlide)
        }.alert("According to you, are racism and colourism the same?", isPresented: $showingAlert) {
            Button("Yes, they are the same") {
                opDat.currView = .wrongDifference
            }
            Button("I'm not sure", role: .cancel) {
                opDat.currView = .idkDifference
            }
            Button("No, they are not") {
                opDat.currView = .rightDifference
            }
        }
    }
    
    var backButton : some View {
            return Button(action: onBackButtonClick)
            {Image(systemName: "arrowshape.turn.up.left.circle.fill")
                    .symbolVariant(.fill)
                    .foregroundStyle(.black, .brown)
                    .padding()
                    .font(.largeTitle)
                    .opacity(centeredText ? 0 : 1)
                    .disabled(centeredText)
            }
        }
    
    let background : some View = Image("Background1").resizable().ignoresSafeArea()
    
    var whiteStripOfText : some View {
        RoundedRectangle(cornerRadius: 50)
            
            .foregroundColor(.white)
            .padding()
            .frame(
                width: MagicNumbers.titleWidth * geometry.size.width,
                height: MagicNumbers.titleHeight * geometry.size.height)
            .padding()
            .overlay(alignment: .center) {
                VStack {
                    UIKitLabelView(text: text, centeredText: centeredText)
                        .dropShadow()
                }
            }.frame(width: UIScreen.main.bounds.width/2 * MagicNumbers.titleWidth, height: UIScreen.main.bounds.height/2 * MagicNumbers.titleWidth)
            .dropShadow()
    }
    
    var finalSlide = false

    // BODY
    var body: some View {
        ZStack {
            background
                .overlay(alignment: .bottomTrailing) {
                    HStack {
                        backButton
                        Spacer()
                        button
                    }
                }.onAppear {
                    opac = true
                }
            whiteStripOfText
        }
    }



}






struct MagicNumbers {
    static let titleWidth = 2.6/3
    static let titleHeight = 0.5/2
    static let textSize1 = CGFloat(0.07)
    static let textSize2 = CGFloat(0.0485)
    static let textSize3 = CGFloat(0.044)
    
    
    static let whiteBGTexts =  [1: "Only HueMan",
                                2: "India is a conglomeration of diverse races and distinct cultures. It also showcases a diversity in the skin tones of people.",
                                3: "However, over the past few decades,instead of celebrating our differences…",
                                4: "…we have started to discriminate each other based on our skin shade. This practice is called colourism."
    ]
    
}



